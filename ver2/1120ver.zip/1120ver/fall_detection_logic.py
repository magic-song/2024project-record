# fall_detection_logic.py

import cv2
import os
from datetime import datetime
from ultralytics import YOLO
import requests

class FallDetectionLogic:
    def __init__(self, model_path, line_token):
        # 加載 YOLO 模型
        self.model = YOLO(model_path)  # 這裡放入訓練後的模型權重路徑

        # 設定儲存圖像的資料夾
        self.save_dir = "detected_falls"
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)

        # 儲存 LINE Notify 權杖
        self.line_token = line_token

        # 初始上次發送圖片的時間變數
        self.last_sent_time = None  

    def run(self, cap, fall_class_id=0, is_video=False):
        if not cap.isOpened():
            print("無法開啟攝影機或影片")
            return
            
        frame_count = 0
            
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame_count += 1                
            if is_video and frame_count % 1 == 0:
                # 偵測
                self.detect_fall(frame, fall_class_id)
            elif is_video == False:
                # 偵測
                self.detect_fall(frame, fall_class_id)
                  
            # 顯示畫面
            cv2.imshow("Fall Detection", frame)

            # esc 退出和檢查視窗是否被關閉
            if cv2.waitKey(1) == 27 or cv2.getWindowProperty("Fall Detection", cv2.WND_PROP_VISIBLE) < 1:
                break

        cap.release()
        cv2.destroyAllWindows()
    
    def detect_fall(self, frame, fall_class_id):
        # 使用模型進行即時影像偵測
        results = self.model.predict(frame, conf=0.5)

        # 遍歷偵測結果，檢查是否有跌倒事件
        for result in results:
            for box in result.boxes:
                cls_id = int(box.cls[0])
                if cls_id == fall_class_id:  # 如果偵測到跌倒事件
                    x1, y1, x2, y2 = map(int, box.xyxy[0])  # 邊界框座標
                    # 繪製邊界框和標籤
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
                    cv2.putText(frame, "Fall Detected", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                    
                    # 當前時間
                    current_time = datetime.now()

                    timestamp = current_time.strftime("%Y%m%d_%H%M%S")  
                    filename = os.path.join(self.save_dir, f"fall_{timestamp}.jpg")
                    cv2.imwrite(filename, frame)
                    print(f"跌倒事件偵測到，畫面已儲存至 {filename}")

                    # 檢查是否已經過了一分鐘 或 第一次發送
                    if self.last_sent_time is None or (current_time - self.last_sent_time).seconds >= 3:
                        # 發送圖片到 LINE Notify
                        self.send_to_line_notify(filename, current_time)
                        # 更新最後一次發送時間
                        self.last_sent_time = current_time

    def send_to_line_notify(self, image_path, time):

        url = 'https://notify-api.line.me/api/notify'  # 指定 LINE Notify 的 API 端點
        headers = {'Authorization': f'Bearer {self.line_token}'}  # 設置 HTTP 請求的標頭。Authorization 是認證標頭，必須包含使用者的 LINE Notify 權杖。 Bearer 是 HTTP 認證機制中的一種身份驗證模式，常用於 API 授權。它代表「持有者（Bearer）」的意思，表示持有這個令牌（token）的人可以被授權進行請求。
        data = {'message': f"{time.year}年{time.month}月{time.day}日 {time.hour:02}:{time.minute:02}:{time.second:02}"}   # 要傳送的訊息
        files = {'imageFile': open(image_path, 'rb')}  # 以二進制方式打開圖片檔案，並將其與關鍵字 'imageFile' 一起傳送。
        
        response = requests.post(url, headers=headers, data=data, files=files)  # 使用 requests.post 發送 HTTP POST 請求到 LINE Notify 服務端
        
        # 檢查伺服器的回應狀態碼
        if response.status_code == 200:
            print("圖片已成功傳送到 LINE Notify")
            #print("Response Headers:", response.headers)
        else:
            print(f"圖片傳送失敗，狀態碼：{response.status_code}")
            #print(response.text)  # 這將會顯示伺服器回應的錯誤細節