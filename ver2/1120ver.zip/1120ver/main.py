# main.py

import sys
import cv2
from PyQt5.QtWidgets import QApplication
from fall_detection_ui import FallDetectionUI
from fall_detection_logic import FallDetectionLogic

def main():
    # 初始化 GUI 應用程式
    app = QApplication(sys.argv)
    window = FallDetectionUI()

    # 連接攝影機按鈕功能
    window.cam_button.clicked.connect(lambda: start_camera(window))

    # 連接選擇影片按鈕功能
    window.video_button.clicked.connect(lambda: open_video(window))

    # 顯示視窗
    window.show()
    sys.exit(app.exec_())

def start_camera(window):
    # 獲取使用者輸入的 Line Token
    line_token = window.line_token_input.text()

    # 檢查 Line Token 是否已輸入
    if not line_token:
        print("請輸入 LINE Token!")
        return

    # 初始化偵測邏輯
    model_path = "best.pt"  # 替換成你的 YOLO 模型權重 ../best.pt
    fall_detector = FallDetectionLogic(model_path, line_token)
    
    # 啟動攝影機偵測
    window.close()  # 關閉主視窗
    fall_detector.run(cv2.VideoCapture(0), is_video=False)

def open_video(window):
    # 獲取使用者輸入的 Line Token
    line_token = window.line_token_input.text()

    # 檢查 Line Token 是否已輸入
    if not line_token:
        print("請輸入 LINE Token!")
        return

    # 初始化偵測邏輯
    model_path = "best.pt"  # 替換成你的 YOLO 模型權重 ../best.pt
    fall_detector = FallDetectionLogic(model_path, line_token)
    
    # 啟動影片偵測
    video_path = window.get_video_file()
    if video_path:
        window.close()  # 關閉主視窗
        fall_detector.run(cv2.VideoCapture(video_path), is_video=True)

if __name__ == '__main__':
    main()
