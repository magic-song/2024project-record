新介面
增加下拉式表單
yolov10 yolov11可用