import cv2
import os
from datetime import datetime
from ultralytics import YOLO
import requests

class FallDetectionLogic:
    def __init__(self, model_path, line_token, window):
        self.model = YOLO(model_path)
        self.model_name = os.path.basename(model_path).split("best")[0]
        self.save_dir = "detected_falls"
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)
        self.line_token = line_token
        self.last_sent_time = None  
        self.window = window

    def run(self, cap, fall_class_id=0, is_video=False):
        if not cap.isOpened():
            print("無法開啟攝影機或影片")
            return
            
        frame_count = 0
            
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame_count += 1                
            if is_video or frame_count % 1 == 0:
                self.detect_fall(frame, fall_class_id)
            '''
            cv2.imshow("Fall Detection", frame)
            if cv2.waitKey(1) == 27 or cv2.getWindowProperty("Fall Detection", cv2.WND_PROP_VISIBLE) < 1:
                break
            '''     
            # 等比例放大顯示視窗
            scale_percent = 130 # 放大比例，這裡是150%
            width = int(frame.shape[1] * scale_percent / 100) 
            height = int(frame.shape[0] * scale_percent / 100) 
            dim = (width, height) 
            # 調整影像大小 
            resized_frame = cv2.resize(frame, dim, interpolation=cv2.INTER_LINEAR) 
            # 顯示等比放大的影像 
            cv2.imshow("Fall Detection", resized_frame) 
            if cv2.waitKey(1) == 27 or cv2.getWindowProperty("Fall Detection", cv2.WND_PROP_VISIBLE) < 1: break

        cap.release()
        cv2.destroyAllWindows()
        self.window.show()
    
    def detect_fall(self, frame, fall_class_id):
        if "pose" in self.model_name:
            self.detect_fall_with_pose(frame, fall_class_id)
        else:
            self.detect_fall_with_bounding_box(frame, fall_class_id)

    def detect_fall_with_bounding_box(self, frame, fall_class_id):
        results = self.model.predict(frame, conf=0.5)
        for result in results:
            for box in result.boxes:
                cls_id = int(box.cls[0])
                if cls_id == fall_class_id:
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)
                    cv2.putText(frame, "Fall Detected", (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                    current_time = datetime.now()
                    timestamp = current_time.strftime("%Y%m%d_%H%M%S")  
                    filename = os.path.join(self.save_dir, f"fall_{timestamp}.jpg")
                    cv2.imwrite(filename, frame)
                    if self.last_sent_time is None or (current_time - self.last_sent_time).seconds >= 3:
                        self.send_to_line_notify(filename, current_time)
                        self.last_sent_time = current_time

    def detect_fall_with_pose(self, frame, fall_class_id):
        results = self.model.predict(frame, conf=0.5)
        for result in results:
            if result.keypoints:
                keypoints_tensor = result.keypoints.xy.cpu()
                keypoints = keypoints_tensor.numpy()
                if keypoints.shape[0] > 0:  # 有偵測測到人，keypoints.shape[0]取得人數
                    self.draw_predictions(frame, result)
                    for person_keypoints in keypoints:  # 遍歷每個人的關鍵點
                        if self.is_fall_pose(person_keypoints):
                            x, y = int(person_keypoints[0][0]), int(person_keypoints[0][1])
                            cv2.putText(frame, "Fall Detected (Pose)", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                            current_time = datetime.now()
                            timestamp = current_time.strftime("%Y%m%d_%H%M%S")
                            filename = os.path.join(self.save_dir, f"fall_{timestamp}.jpg")
                            cv2.imwrite(filename, frame)
                            if self.last_sent_time is None or (current_time - self.last_sent_time).seconds >= 3:
                                self.send_to_line_notify(filename, current_time)
                                self.last_sent_time = current_time

    def draw_predictions(self, frame, result):
        # 繪製預測框
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = box.conf[0]
            cls = int(box.cls[0])
            label = f"{cls} {conf:.2f}"
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

        # 繪製關鍵點並標號，顯示所有人
        for person_keypoints in result.keypoints.xy:
            for i, keypoint in enumerate(person_keypoints):
                x, y = int(keypoint[0]), int(keypoint[1])
                if x == 0 and y == 0:
                    cv2.circle(frame, (x, y), 5, (255, 0, 0), -1)
                    cv2.putText(frame, f"KP{i}", (x + 5, y + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                else:
                    cv2.circle(frame, (x, y), 5, (0, 0, 255), -1)
                    cv2.putText(frame, f"KP{i}", (x + 5, y + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)


    def is_fall_pose(self, keypoints):
        if len(keypoints) == 17:
            head_y = keypoints[0][1]
            hip_y = keypoints[11][1]
            knee_y = keypoints[13][1]
            if head_y != 0 and hip_y != 0 and knee_y != 0:
                if head_y >= knee_y and hip_y >= knee_y:
                    return True
        return False

    def send_to_line_notify(self, image_path, time):
        url = 'https://notify-api.line.me/api/notify'
        headers = {'Authorization': f'Bearer {self.line_token}'}
        data = {'message': f"{time.year}年{time.month}月{time.day}日 {time.hour:02}:{time.minute:02}:{time.second:02}"}
        files = {'imageFile': open(image_path, 'rb')}
        response = requests.post(url, headers=headers, data=data, files=files)
        if response.status_code == 200:
            print("圖片已成功傳送到 LINE Notify")
        else:
            print(f"圖片傳送失敗，狀態碼：{response.status_code}")
